import { NextResponse, type NextRequest } from "next/server";
import { GATE_COOKIE, GATE_PATH, gateEnabled, verifyToken } from "@/lib/gate";

/**
 * Pre-launch password gate. Every page, image and API call needs the preview cookie;
 * without it, pages redirect to /unlock and APIs answer 401.
 * Set SITE_GATE=off on the host to open the site at launch.
 */
export async function proxy(req: NextRequest) {
  if (!gateEnabled()) return NextResponse.next();

  if (await verifyToken(req.cookies.get(GATE_COOKIE)?.value)) {
    const res = NextResponse.next();
    res.headers.set("X-Robots-Tag", "noindex, nofollow");
    // Keep shared caches/CDNs from storing protected pages and serving them to locked-out visitors.
    res.headers.set("Cache-Control", "private, no-store");
    return res;
  }

  const { pathname, search } = req.nextUrl;
  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "This preview is password protected." }, { status: 401, headers: { "X-Robots-Tag": "noindex" } });
  }

  const url = req.nextUrl.clone();
  url.pathname = GATE_PATH;
  url.search = pathname === "/" && !search ? "" : `?next=${encodeURIComponent(pathname + search)}`;
  const res = NextResponse.redirect(url, 307);
  res.headers.set("Cache-Control", "no-store");
  res.headers.set("X-Robots-Tag", "noindex, nofollow");
  return res;
}

export const config = {
  // Everything except the unlock page, its endpoint and logo, build assets, the favicon and robots.txt.
  matcher: ["/((?!unlock|api/unlock|_next/static|icon\\.svg|robots\\.txt|images/wordmark\\.png).*)"],
};
