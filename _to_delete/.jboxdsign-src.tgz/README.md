# JBOX iDsign LLC: Landing Page

Single-page website for JBOX iDsign LLC (Fremont, CA), built from the approved Figma design
"Design 1: Minimal and Direct". Next.js 16 (App Router), React 19, TypeScript, no UI or animation libraries.

## Getting started

```bash
npm install
npm run dev          # http://localhost:3000
```

Copy `.env.example` to `.env.local` and fill in values before deploying.

| Script | What it does |
| --- | --- |
| `npm run dev` | Development server |
| `npm run build` / `npm start` | Production build and server |
| `npm run typecheck` | TypeScript check |
| `npm test` | Unit and API tests (`qa/*.test.ts`, Node test runner via tsx) |
| `npm run qa` | Typecheck + unit tests |
| `npm run qa:e2e` | Builds if needed, starts the server and runs browser checks with Playwright. First time: `npx playwright install chromium` |

## Structure

```
src/
  app/
    layout.tsx         fonts (self-hosted), metadata, Open Graph, JSON-LD
    page.tsx           section order
    globals.css        design tokens, layout, responsive rules, all motion
    api/contact/       POST endpoint for the inquiry form
    sitemap.ts, robots.ts, icon.svg, not-found.tsx
    fonts/             Manrope, Inter, IBM Plex Mono (SIL OFL)
  components/
    Header.tsx         hide-on-scroll header, scroll-spy underline, mobile menu
    ui.tsx             buttons, arrow links, section heads, masked headings, cube logo
    motion/            MotionRoot (reveals, parallax, progress), CountUp, Magnetic
    sections/          Hero, Stats, Services, Projects, Why, About, ClosingCta, Contact, ContactForm, Footer
  content/site.ts      ALL page copy and contact details: edit content here
  lib/                 contact validation, mailer, helpers
public/images/         images exported from the Figma file
qa/
  *.test.ts            unit + API tests
  e2e/                 Playwright browser checks and screenshots
```

## Motion

All animation is CSS-driven and switched on by a single client component (`MotionRoot`):

- Hero: staggered line-mask headline, eyebrow rule draws in, image settles from a slight zoom, gentle parallax
- Logo cube strokes draw on load; header slides in, hides on scroll down, returns on scroll up
- Scroll progress hairline at the top of the page
- Nav underline slides to the section in view
- Section rules draw left to right; headings rise from behind a mask; content fades up
- Images reveal with a clip wipe, then zoom slightly on hover
- Stats count up when they enter the viewport
- Buttons: fill sweep plus rolling label; primary CTAs lean slightly toward the cursor
- Form fields: underline grows on focus; project CTAs ("Discuss a kitchen project") preselect the project type
- Animated check mark on successful submit

Everything respects `prefers-reduced-motion`, and content stays visible without JavaScript.

## Contact form

`POST /api/contact` validates input (shared with the browser), has a honeypot field and a simple per-IP rate limit.
Delivery uses [Resend](https://resend.com) when `RESEND_API_KEY` is set. Without a key, development logs inquiries
to the terminal; production returns an error that points visitors to the phone number and email, so no
inquiry is silently lost.

## Content still to be supplied by the client

These are shown as clearly labeled placeholders:

- As-Built Plans image (Polycam scans / existing conditions)
- BIM image (Revit screenshot)
- Short bio for Julius Ken Bacinillo
- Confirmation that jboxdsign@gmail.com is the receiving inbox
- Production domain for `NEXT_PUBLIC_SITE_URL`
