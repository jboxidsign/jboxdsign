import assert from "node:assert/strict";
import { afterEach, beforeEach, describe, it } from "node:test";
import { POST } from "../src/app/api/contact/route";
import type { ContactInput } from "../src/lib/contact";
import { setMailer } from "../src/lib/mailer";

let sent: ContactInput[] = [];
let ipCounter = 0;

beforeEach(() => {
  sent = [];
  setMailer({
    async send(input) {
      sent.push(input);
      return { delivered: true, via: "resend" };
    },
  });
});
afterEach(() => setMailer(undefined));

const VALID = { name: "Jane Doe", email: "jane@example.com", message: "Bathroom remodel in Fremont." };

function post(body: unknown, opts: { raw?: boolean; type?: string; ip?: string } = {}) {
  return POST(
    new Request("http://test/api/contact", {
      method: "POST",
      headers: {
        "content-type": opts.type ?? "application/json",
        "x-forwarded-for": opts.ip ?? `10.0.0.${++ipCounter}`,
      },
      body: opts.raw ? (body as string) : JSON.stringify(body),
    }),
  );
}

describe("POST /api/contact", () => {
  it("delivers a valid inquiry", async () => {
    const res = await post({ ...VALID, projectType: "Bathroom Remodeling" });
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { ok: true });
    assert.equal(sent.length, 1);
    assert.equal(sent[0].projectType, "Bathroom Remodeling");
  });

  it("returns field errors for invalid input and sends nothing", async () => {
    const res = await post({ name: "", email: "nope", message: "" });
    assert.equal(res.status, 422);
    const body = (await res.json()) as { fieldErrors: Record<string, string> };
    assert.deepEqual(Object.keys(body.fieldErrors).sort(), ["email", "message", "name"]);
    assert.equal(sent.length, 0);
  });

  it("rejects bad JSON and wrong content types", async () => {
    assert.equal((await post("{not json", { raw: true })).status, 400);
    assert.equal((await post("[1,2]", { raw: true })).status, 400);
    assert.equal((await post("name=x", { raw: true, type: "application/x-www-form-urlencoded" })).status, 415);
    assert.equal(sent.length, 0);
  });

  it("quietly accepts but drops honeypot submissions", async () => {
    const res = await post({ ...VALID, company: "Spam Inc" });
    assert.equal(res.status, 200);
    assert.equal(sent.length, 0);
  });

  it("rate limits repeated submissions from one address", async () => {
    const statuses: number[] = [];
    for (let i = 0; i < 6; i++) statuses.push((await post(VALID, { ip: "203.0.113.9" })).status);
    assert.deepEqual(statuses, [200, 200, 200, 200, 200, 429]);
  });

  it("reports delivery failures without leaking details", async () => {
    setMailer({
      async send() {
        throw new Error("secret provider error");
      },
    });
    const quiet = console.error;
    console.error = () => {};
    try {
      const res = await post(VALID);
      assert.equal(res.status, 502);
      const body = (await res.json()) as { error: string };
      assert.doesNotMatch(body.error, /secret/);
      assert.match(body.error, /925-759-6847/);
    } finally {
      console.error = quiet;
    }
  });
});
