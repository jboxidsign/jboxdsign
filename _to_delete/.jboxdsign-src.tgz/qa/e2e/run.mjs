// Builds (if needed), starts the production server, runs the browser checks, then stops the server.
// Usage: npm run qa:e2e          (first time: npx playwright install chromium)
import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const port = process.env.E2E_PORT || "3456";
const base = `http://localhost:${port}`;
const nextBin = path.join(root, "node_modules", "next", "dist", "bin", "next");

if (!fs.existsSync(path.join(root, ".next", "BUILD_ID")) || process.argv.includes("--build")) {
  console.log("Building…");
  const b = spawnSync(process.execPath, [nextBin, "build"], { cwd: root, stdio: "inherit" });
  if (b.status !== 0) process.exit(b.status ?? 1);
}

// CONTACT_ALLOW_LOG_ONLY lets the form test pass without a real email key (inquiries are only logged).
const server = spawn(process.execPath, [nextBin, "start", "-p", port], {
  cwd: root,
  stdio: ["ignore", "pipe", "pipe"],
  env: { ...process.env, CONTACT_ALLOW_LOG_ONLY: "1" },
});
let log = "";
server.stdout.on("data", (d) => (log += d));
server.stderr.on("data", (d) => (log += d));

async function waitForServer() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(base);
      if (r.ok) return;
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(`Server did not start:\n${log}`);
}

let code = 1;
try {
  await waitForServer();
  const { run } = await import("./app.e2e.mjs");
  code = await run(base);
} catch (err) {
  console.error(err);
} finally {
  server.kill();
}
process.exit(code);
