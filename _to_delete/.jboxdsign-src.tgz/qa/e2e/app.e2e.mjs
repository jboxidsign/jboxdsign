// Browser checks for the landing page. Screenshots go to qa/e2e/screenshots/ (git-ignored).
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const shots = path.join(path.dirname(fileURLToPath(import.meta.url)), "screenshots");

const VIEWPORTS = {
  desktop: { width: 1440, height: 900 },
  tablet: { width: 834, height: 1112 },
  mobile: { width: 390, height: 844 },
};

async function scrollThrough(page) {
  const h = await page.evaluate(() => document.body.scrollHeight);
  for (let y = 0; y < h; y += 350) {
    await page.evaluate((v) => window.scrollTo(0, v), y);
    await page.waitForTimeout(80);
  }
  await page.waitForTimeout(1400);
}

export async function run(base) {
  fs.mkdirSync(shots, { recursive: true });
  const browser = await chromium.launch();
  const results = [];

  async function test(name, fn) {
    try {
      await fn();
      results.push([true, name]);
      console.log(`  ✓ ${name}`);
    } catch (err) {
      results.push([false, name]);
      console.log(`  ✗ ${name}\n    ${String(err?.message ?? err).split("\n").join("\n    ")}`);
    }
  }

  async function open(viewport = VIEWPORTS.desktop, opts = {}) {
    const ctx = await browser.newContext({ viewport, ...opts });
    const page = await ctx.newPage();
    const errors = [];
    page.on("pageerror", (e) => errors.push(e.message));
    page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
    await page.goto(base, { waitUntil: "networkidle" });
    return { ctx, page, errors };
  }

  console.log(`\nE2E against ${base}`);

  await test("renders every section with no console errors", async () => {
    const { ctx, page, errors } = await open();
    for (const id of ["top", "credibility", "services", "projects", "why", "about", "contact"]) {
      assert.equal(await page.locator(`#${id}`).count(), 1, `#${id}`);
    }
    assert.equal(await page.locator("h1").count(), 1);
    assert.match(await page.locator("h1").getAttribute("aria-label"), /Thoughtfully Designed\. Personally Understood\./);
    await scrollThrough(page);
    assert.deepEqual(errors, []);
    await ctx.close();
  });

  await test("all images load", async () => {
    const { ctx, page } = await open();
    await scrollThrough(page);
    const broken = await page.evaluate(() => [...document.images].filter((i) => !i.complete || i.naturalWidth === 0).map((i) => i.src));
    assert.deepEqual(broken, []);
    await ctx.close();
  });

  await test("scroll reveals end up visible", async () => {
    const { ctx, page } = await open();
    await scrollThrough(page);
    const hidden = await page.evaluate(() => [...document.querySelectorAll("[data-reveal]")].filter((el) => !el.classList.contains("is-in")).length);
    assert.equal(hidden, 0);
    await ctx.close();
  });

  await test("stats count up to their final values", async () => {
    const { ctx, page } = await open();
    await page.locator("#credibility").scrollIntoViewIfNeeded();
    await page.waitForTimeout(2000);
    const text = await page.locator("#credibility").innerText();
    assert.match(text, /2018/);
    assert.match(text, /\d+\s*years/);
    await ctx.close();
  });

  await test("header hides on scroll down and returns on scroll up; nav highlights the section", async () => {
    const { ctx, page } = await open();
    await page.mouse.wheel(0, 1600);
    await page.waitForTimeout(700);
    assert.ok(await page.locator(".site-header.is-hidden").count(), "hidden after scrolling down");
    await page.mouse.wheel(0, -300);
    await page.waitForTimeout(700);
    assert.equal(await page.locator(".site-header.is-hidden").count(), 0, "visible after scrolling up");
    await page.locator("#projects").scrollIntoViewIfNeeded();
    await page.evaluate(() => window.scrollBy(0, 200));
    await page.waitForTimeout(700);
    assert.equal(await page.locator('.site-header__nav a[aria-current="true"]').innerText(), "Projects");
    await ctx.close();
  });

  await test("project CTA preselects the project type in the form", async () => {
    const { ctx, page } = await open();
    await page.locator('a[data-project-type="ADU & Home Addition"]').click();
    await page.waitForTimeout(900);
    assert.equal(await page.locator('select[name="projectType"]').inputValue(), "ADU & Home Addition");
    await ctx.close();
  });

  await test("form shows errors for empty required fields and focuses the first", async () => {
    const { ctx, page } = await open();
    await page.locator("#contact").scrollIntoViewIfNeeded();
    await page.locator('form button[type="submit"]').click();
    const errs = await page.locator(".field__error").allInnerTexts();
    assert.equal(errs.filter(Boolean).length, 3);
    assert.equal(await page.evaluate(() => document.activeElement?.getAttribute("name")), "name");
    await page.screenshot({ path: path.join(shots, "form-errors.png") });
    await ctx.close();
  });

  await test("form submits and shows the thank-you state", async () => {
    const { ctx, page } = await open();
    await page.locator("#contact").scrollIntoViewIfNeeded();
    await page.fill('input[name="name"]', "QA Tester");
    await page.fill('input[name="email"]', "qa@example.com");
    await page.selectOption('select[name="projectType"]', "Permitting");
    await page.fill('textarea[name="message"]', "Automated test inquiry, please ignore.");
    await page.locator('form button[type="submit"]').click();
    await page.locator(".form-success").waitFor({ timeout: 8000 });
    assert.match(await page.locator(".form-success").innerText(), /Thank you/);
    await page.waitForTimeout(1200);
    await page.locator("#contact").screenshot({ path: path.join(shots, "form-success.png") });
    await ctx.close();
  });

  await test("mobile menu opens, links work, Escape closes it", async () => {
    const { ctx, page } = await open(VIEWPORTS.mobile, { hasTouch: true, isMobile: true });
    const toggle = page.locator(".menu-toggle");
    await toggle.click();
    await page.waitForTimeout(700);
    assert.equal(await toggle.getAttribute("aria-expanded"), "true");
    await page.screenshot({ path: path.join(shots, "mobile-menu.png") });
    await page.keyboard.press("Escape");
    assert.equal(await toggle.getAttribute("aria-expanded"), "false");
    await toggle.click();
    await page.locator('#mobile-menu a[href="#about"]').click();
    await page.waitForTimeout(1200);
    assert.equal(await toggle.getAttribute("aria-expanded"), "false");
    assert.ok(await page.evaluate(() => window.scrollY > 1000));
    assert.ok(await page.locator(".action-bar").isVisible(), "fixed action bar on phones");
    await ctx.close();
  });

  await test("no horizontal overflow at any size", async () => {
    for (const [name, vp] of Object.entries(VIEWPORTS)) {
      const { ctx, page } = await open(vp);
      const over = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      assert.equal(over, 0, name);
      await ctx.close();
    }
  });

  await test("reduced motion shows all content immediately", async () => {
    const { ctx, page } = await open(VIEWPORTS.desktop, { reducedMotion: "reduce" });
    const hidden = await page.evaluate(() => [...document.querySelectorAll("[data-reveal]")].filter((el) => getComputedStyle(el).opacity === "0").length);
    assert.equal(hidden, 0);
    await ctx.close();
  });

  await test("SEO basics: title, description, canonical, JSON-LD, robots, sitemap", async () => {
    const { ctx, page } = await open();
    assert.match(await page.title(), /JBOX iDsign/);
    assert.ok(await page.locator('meta[name="description"]').getAttribute("content"));
    assert.ok(await page.locator('link[rel="canonical"]').count());
    const ld = JSON.parse(await page.locator('script[type="application/ld+json"]').innerText());
    assert.equal(ld.telephone, "+1-925-759-6847");
    assert.equal((await page.request.get(`${base}/robots.txt`)).status(), 200);
    assert.equal((await page.request.get(`${base}/sitemap.xml`)).status(), 200);
    await ctx.close();
  });

  await test("full-page screenshots", async () => {
    for (const [name, vp] of Object.entries(VIEWPORTS)) {
      const { ctx, page } = await open(vp);
      await scrollThrough(page);
      await page.evaluate(() => window.scrollTo(0, 0));
      await page.waitForTimeout(900);
      await page.screenshot({ path: path.join(shots, `${name}.png`), fullPage: true });
      await ctx.close();
    }
  });

  await browser.close();
  const failed = results.filter(([ok]) => !ok).length;
  console.log(`\n${results.length - failed} passed, ${failed} failed. Screenshots: ${shots}\n`);
  return failed ? 1 : 0;
}
