import { createRateLimiter, validateContact } from "@/lib/contact";
import { getMailer } from "@/lib/mailer";

export const runtime = "nodejs";

const allow = createRateLimiter(5, 10 * 60 * 1000);
const json = (body: unknown, status = 200) => Response.json(body, { status });

export async function POST(req: Request): Promise<Response> {
  const type = req.headers.get("content-type") ?? "";
  if (!type.includes("application/json")) return json({ error: "Unsupported content type." }, 415);

  const len = Number(req.headers.get("content-length") ?? 0);
  if (len > 20_000) return json({ error: "Message is too large." }, 413);

  let body: Record<string, unknown>;
  try {
    const parsed: unknown = await req.json();
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("not an object");
    body = parsed as Record<string, unknown>;
  } catch {
    return json({ error: "Invalid request." }, 400);
  }

  // Honeypot: real visitors never see or fill the "company" field.
  if (typeof body.company === "string" && body.company.trim() !== "") return json({ ok: true });

  const ip = (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || "local";
  if (!allow(ip)) return json({ error: "Too many messages. Please call us or try again later." }, 429);

  const result = validateContact(body);
  if (!result.ok) return json({ error: "Please check the highlighted fields.", fieldErrors: result.errors }, 422);

  try {
    await getMailer().send(result.data);
    return json({ ok: true });
  } catch (err) {
    console.error("[contact] delivery failed", err);
    return json({ error: "We couldn't send your message. Please call 925-759-6847 or email jboxdsign@gmail.com." }, 502);
  }
}
