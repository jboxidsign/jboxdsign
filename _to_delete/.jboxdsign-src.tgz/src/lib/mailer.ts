import type { ContactInput } from "./contact";
import { formatInquiry } from "./contact";

export type DeliveryResult = { delivered: boolean; via: "resend" | "log" };

export interface Mailer {
  send(input: ContactInput): Promise<DeliveryResult>;
}

/** Sends through Resend when RESEND_API_KEY is set; otherwise logs on the server. */
export const defaultMailer: Mailer = {
  async send(input) {
    const { subject, text } = formatInquiry(input);
    const key = process.env.RESEND_API_KEY;
    if (!key) {
      // In production, never tell a visitor their message was sent when nobody will receive it.
      if (process.env.NODE_ENV === "production" && process.env.CONTACT_ALLOW_LOG_ONLY !== "1") {
        throw new Error("RESEND_API_KEY is not set");
      }
      console.info(`[contact] ${subject}\n${text}`);
      return { delivered: false, via: "log" };
    }
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.CONTACT_FROM_EMAIL || "JBOX iDsign Website <onboarding@resend.dev>",
        to: [process.env.CONTACT_TO_EMAIL || "jboxdsign@gmail.com"],
        reply_to: input.email,
        subject,
        text,
      }),
    });
    if (!res.ok) throw new Error(`Email provider responded ${res.status}`);
    return { delivered: true, via: "resend" };
  },
};

let current: Mailer = defaultMailer;
export const getMailer = () => current;
/** Test hook. Pass undefined to restore the default. */
export const setMailer = (m: Mailer | undefined) => {
  current = m ?? defaultMailer;
};
