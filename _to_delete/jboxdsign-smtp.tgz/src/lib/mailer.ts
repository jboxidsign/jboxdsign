import nodemailer, { type Transporter } from "nodemailer";
import type { ContactInput } from "./contact";
import { formatInquiry } from "./contact";

/** Every inquiry goes here unless CONTACT_TO_EMAIL overrides it. */
export const DEFAULT_RECIPIENT = "stadosuyos@gmail.com";

export type DeliveryResult = { delivered: boolean; via: "smtp" | "log"; messageId?: string };

export interface Mailer {
  send(input: ContactInput): Promise<DeliveryResult>;
}

type Env = Record<string, string | undefined>;

export type SmtpConfig = {
  host: string;
  port: number;
  secure: boolean;
  user?: string;
  pass?: string;
  from: string;
  to: string;
};

/** Reads SMTP settings from env. Returns null when SMTP_HOST is not set. */
export function smtpConfig(env: Env = process.env): SmtpConfig | null {
  const host = env.SMTP_HOST?.trim();
  if (!host) return null;
  const port = Number(env.SMTP_PORT) || 465;
  const secure = env.SMTP_SECURE ? env.SMTP_SECURE.toLowerCase() === "true" : port === 465;
  const user = env.SMTP_USER?.trim() || undefined;
  const pass = env.SMTP_PASS || undefined;
  // Most providers (Gmail included) only accept a From address that belongs to the login.
  const from = env.CONTACT_FROM_EMAIL?.trim() || (user ? `"JBOX iDsign Website" <${user}>` : "JBOX iDsign Website <no-reply@localhost>");
  const to = env.CONTACT_TO_EMAIL?.trim() || DEFAULT_RECIPIENT;
  return { host, port, secure, user, pass, from, to };
}

const escapeHtml = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

/** HTML version of the inquiry email (the plain-text version comes from formatInquiry). */
export function inquiryHtml(d: ContactInput, receivedAt: Date = new Date()): string {
  const row = (label: string, value: string) =>
    `<tr><td style="padding:8px 16px 8px 0;color:#6a6a6a;font:12px/1.4 monospace;text-transform:uppercase;letter-spacing:.08em;vertical-align:top;white-space:nowrap">${label}</td><td style="padding:8px 0;font:15px/1.5 Arial,sans-serif;color:#111">${value}</td></tr>`;
  return `<!doctype html><html><body style="margin:0;padding:24px;background:#f2f2f0">
<table role="presentation" style="max-width:600px;margin:0 auto;background:#fff;border-collapse:collapse;width:100%">
<tr><td style="padding:24px 28px;background:#111;color:#fff;font:600 18px/1.3 Arial,sans-serif">New project inquiry</td></tr>
<tr><td style="padding:20px 28px"><table role="presentation" style="border-collapse:collapse">
${row("Name", escapeHtml(d.name))}
${row("Email", `<a href="mailto:${escapeHtml(d.email)}" style="color:#111">${escapeHtml(d.email)}</a>`)}
${row("Phone", d.phone ? escapeHtml(d.phone) : "Not provided")}
${row("Project type", d.projectType ? escapeHtml(d.projectType) : "Not specified")}
${row("Received", escapeHtml(receivedAt.toUTCString()))}
</table>
<div style="margin-top:16px;padding-top:16px;border-top:1px solid #d9d9d5;font:15px/1.6 Arial,sans-serif;color:#111;white-space:pre-wrap">${escapeHtml(d.message)}</div>
<p style="margin:24px 0 0;font:12px/1.5 Arial,sans-serif;color:#6a6a6a">Sent from the contact form on the JBOX iDsign website. Reply to this email to answer ${escapeHtml(d.name)} directly.</p>
</td></tr></table></body></html>`;
}

let cached: { key: string; transport: Transporter } | null = null;
function transportFor(cfg: SmtpConfig): Transporter {
  const key = JSON.stringify([cfg.host, cfg.port, cfg.secure, cfg.user, cfg.pass]);
  if (cached?.key !== key) {
    cached = {
      key,
      transport: nodemailer.createTransport({
        host: cfg.host,
        port: cfg.port,
        secure: cfg.secure,
        auth: cfg.user && cfg.pass ? { user: cfg.user, pass: cfg.pass } : undefined,
        connectionTimeout: 10_000,
        greetingTimeout: 10_000,
        socketTimeout: 20_000,
      }),
    };
  }
  return cached.transport;
}

/** Sends every inquiry by SMTP. Without SMTP settings it logs in development and refuses in production. */
export const smtpMailer: Mailer = {
  async send(input) {
    const cfg = smtpConfig();
    const receivedAt = new Date();
    const { subject, text } = formatInquiry(input, receivedAt);
    if (!cfg) {
      // In production, never tell a visitor their message was sent when nobody will receive it.
      if (process.env.NODE_ENV === "production" && process.env.CONTACT_ALLOW_LOG_ONLY !== "1") {
        throw new Error("SMTP is not configured (SMTP_HOST is missing)");
      }
      console.info(`[contact] SMTP not configured; would send to ${process.env.CONTACT_TO_EMAIL || DEFAULT_RECIPIENT}\n${subject}\n${text}`);
      return { delivered: false, via: "log" };
    }
    const info = await transportFor(cfg).sendMail({
      from: cfg.from,
      to: cfg.to,
      replyTo: { name: input.name, address: input.email },
      subject,
      text,
      html: inquiryHtml(input, receivedAt),
    });
    if (info.rejected?.length) throw new Error(`SMTP server rejected the recipient`);
    return { delivered: true, via: "smtp", messageId: info.messageId };
  },
};

export const defaultMailer = smtpMailer;

let current: Mailer = defaultMailer;
export const getMailer = () => current;
/** Test hook. Pass undefined to restore the default. */
export const setMailer = (m: Mailer | undefined) => {
  current = m ?? defaultMailer;
};
