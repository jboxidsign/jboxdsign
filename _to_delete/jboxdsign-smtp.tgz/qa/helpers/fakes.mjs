// Local stand-ins for external services, used by unit and e2e tests so nothing leaves the machine.
import http from "node:http";
import net from "node:net";

/**
 * Minimal SMTP server that accepts everything and keeps the messages in memory.
 * Supports EHLO/HELO, AUTH PLAIN/LOGIN, MAIL, RCPT, DATA, RSET, NOOP, QUIT (no TLS).
 */
export async function startSmtpSink() {
  const messages = [];
  const server = net.createServer((socket) => {
    socket.setEncoding("utf8");
    let buf = "";
    let mode = "cmd";
    let msg = { from: "", to: [], data: "", auth: null };
    const reply = (line) => socket.write(line + "\r\n");
    reply("220 sink.local ESMTP test");

    socket.on("data", (chunk) => {
      buf += chunk;
      while (true) {
        if (mode === "data") {
          const end = buf.indexOf("\r\n.\r\n");
          if (end === -1) return;
          msg.data = buf.slice(0, end).replace(/^\.\./gm, ".");
          buf = buf.slice(end + 5);
          messages.push(msg);
          msg = { from: "", to: [], data: "", auth: msg.auth };
          mode = "cmd";
          reply("250 2.0.0 queued");
          continue;
        }
        const nl = buf.indexOf("\r\n");
        if (nl === -1) return;
        const line = buf.slice(0, nl);
        buf = buf.slice(nl + 2);
        if (mode === "auth-user") {
          msg.auth = { user: Buffer.from(line, "base64").toString() };
          mode = "auth-pass";
          reply("334 UGFzc3dvcmQ6");
          continue;
        }
        if (mode === "auth-pass") {
          msg.auth.pass = Buffer.from(line, "base64").toString();
          mode = "cmd";
          reply("235 2.7.0 Authentication successful");
          continue;
        }
        const [cmd, ...rest] = line.split(" ");
        const arg = rest.join(" ");
        switch (cmd.toUpperCase()) {
          case "EHLO":
            reply("250-sink.local");
            reply("250-AUTH PLAIN LOGIN");
            reply("250 8BITMIME");
            break;
          case "HELO":
            reply("250 sink.local");
            break;
          case "AUTH": {
            const [method, initial] = arg.split(" ");
            if (method.toUpperCase() === "PLAIN" && initial) {
              const [, user, pass] = Buffer.from(initial, "base64").toString().split("\0");
              msg.auth = { user, pass };
              reply("235 2.7.0 Authentication successful");
            } else if (method.toUpperCase() === "LOGIN") {
              mode = "auth-user";
              reply("334 VXNlcm5hbWU6");
            } else reply("504 unsupported");
            break;
          }
          case "MAIL":
            msg.from = (arg.match(/<([^>]*)>/) ?? [])[1] ?? "";
            reply("250 2.1.0 OK");
            break;
          case "RCPT":
            msg.to.push((arg.match(/<([^>]*)>/) ?? [])[1] ?? "");
            reply("250 2.1.5 OK");
            break;
          case "DATA":
            mode = "data";
            reply("354 End data with <CR><LF>.<CR><LF>");
            break;
          case "RSET":
            msg = { from: "", to: [], data: "", auth: msg.auth };
            reply("250 OK");
            break;
          case "NOOP":
            reply("250 OK");
            break;
          case "QUIT":
            reply("221 Bye");
            socket.end();
            return;
          default:
            reply("502 Command not implemented");
        }
      }
    });
    socket.on("error", () => {});
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  return {
    port: server.address().port,
    messages,
    close: () => new Promise((r) => server.close(r)),
  };
}

/** Cloudflare's documented dummy token, produced by the test sitekeys. */
export const DUMMY_TOKEN = "XXXX.DUMMY.TOKEN.XXXX";
/** Cloudflare's documented "always passes" test secret. */
export const TEST_SECRET = "1x0000000000000000000000000000000AA";

/** Fake Turnstile siteverify endpoint: passes only the dummy token with the test secret. */
export async function startFakeSiteverify() {
  const calls = [];
  const server = http.createServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      const p = new URLSearchParams(body);
      const call = { secret: p.get("secret"), response: p.get("response"), remoteip: p.get("remoteip") };
      calls.push(call);
      const ok = call.secret === TEST_SECRET && call.response === DUMMY_TOKEN;
      res.setHeader("content-type", "application/json");
      res.end(JSON.stringify(ok ? { success: true, hostname: "example.com", "error-codes": [] } : { success: false, "error-codes": ["invalid-input-response"] }));
    });
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  return {
    url: `http://127.0.0.1:${server.address().port}/turnstile/v0/siteverify`,
    calls,
    close: () => new Promise((r) => server.close(r)),
  };
}

/** Browser-side stand-in for https://challenges.cloudflare.com/turnstile/v0/api.js (used with page.route). */
export const FAKE_TURNSTILE_SCRIPT = `
window.turnstile = {
  _n: 0, _w: {},
  render(el, opts) {
    const id = "w" + (++this._n);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "fake-turnstile";
    btn.textContent = "Verify you are human";
    btn.style.cssText = "height:65px;width:100%;border:1px solid #ccc;background:#fafafa;font:14px sans-serif;cursor:pointer";
    btn.onclick = () => { btn.textContent = "Success!"; opts.callback && opts.callback(${JSON.stringify(DUMMY_TOKEN)}); };
    el.appendChild(btn);
    this._w[id] = { el: btn, opts };
    return id;
  },
  reset(id) { const w = this._w[id]; if (w) w.el.textContent = "Verify you are human"; },
  remove(id) { const w = this._w[id]; if (w) { w.el.remove(); delete this._w[id]; } },
};`;
