export type SinkMessage = { from: string; to: string[]; data: string; auth: { user: string; pass?: string } | null };
export function startSmtpSink(): Promise<{ port: number; messages: SinkMessage[]; close: () => Promise<void> }>;
export const DUMMY_TOKEN: string;
export const TEST_SECRET: string;
export function startFakeSiteverify(): Promise<{
  url: string;
  calls: { secret: string | null; response: string | null; remoteip: string | null }[];
  close: () => Promise<void>;
}>;
export const FAKE_TURNSTILE_SCRIPT: string;
