import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { DEFAULT_RECIPIENT, inquiryHtml, smtpConfig, smtpMailer } from "../src/lib/mailer";
import type { ContactInput } from "../src/lib/contact";
import { startSmtpSink } from "./helpers/fakes.mjs";

const INQUIRY: ContactInput = {
  name: "Jane <b>Doe</b>",
  email: "jane@example.com",
  phone: "925-555-0100",
  projectType: "ADU & Home Addition",
  message: "Backyard ADU for my parents.\nSecond line.",
};

function withEnv<T>(vars: Record<string, string | undefined>, fn: () => Promise<T>): Promise<T> {
  const old: Record<string, string | undefined> = {};
  for (const k of Object.keys(vars)) {
    old[k] = process.env[k];
    if (vars[k] === undefined) delete process.env[k];
    else process.env[k] = vars[k];
  }
  return fn().finally(() => {
    for (const k of Object.keys(old)) {
      if (old[k] === undefined) delete process.env[k];
      else process.env[k] = old[k];
    }
  });
}

describe("smtpConfig", () => {
  it("is off without SMTP_HOST", () => {
    assert.equal(smtpConfig({}), null);
  });
  it("defaults to port 465 with TLS and sends to the default recipient", () => {
    const c = smtpConfig({ SMTP_HOST: "smtp.gmail.com", SMTP_USER: "site@gmail.com", SMTP_PASS: "app-pass" })!;
    assert.deepEqual(c, {
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      user: "site@gmail.com",
      pass: "app-pass",
      from: '"JBOX iDsign Website" <site@gmail.com>',
      to: "stadosuyos@gmail.com",
    });
  });
  it("uses STARTTLS-style settings on 587 and honours overrides", () => {
    const c = smtpConfig({ SMTP_HOST: "mail.x", SMTP_PORT: "587", CONTACT_TO_EMAIL: "other@x.com", CONTACT_FROM_EMAIL: "Site <a@x.com>" })!;
    assert.equal(c.secure, false);
    assert.equal(c.to, "other@x.com");
    assert.equal(c.from, "Site <a@x.com>");
    assert.equal(smtpConfig({ SMTP_HOST: "mail.x", SMTP_PORT: "2525", SMTP_SECURE: "true" })!.secure, true);
  });
  it("sends to stadosuyos@gmail.com by default", () => {
    assert.equal(DEFAULT_RECIPIENT, "stadosuyos@gmail.com");
  });
});

describe("inquiryHtml", () => {
  it("escapes visitor input", () => {
    const html = inquiryHtml(INQUIRY);
    assert.doesNotMatch(html, /<b>Doe<\/b>/);
    assert.match(html, /Jane &lt;b&gt;Doe&lt;\/b&gt;/);
    assert.match(html, /ADU &amp; Home Addition/);
  });
});

describe("smtpMailer.send", () => {
  let sink: Awaited<ReturnType<typeof startSmtpSink>>;
  before(async () => (sink = await startSmtpSink()));
  after(() => sink.close());

  it("delivers the inquiry by SMTP to stadosuyos@gmail.com with reply-to set to the visitor", () =>
    withEnv(
      { SMTP_HOST: "127.0.0.1", SMTP_PORT: String(sink.port), SMTP_SECURE: "false", SMTP_USER: "site@example.com", SMTP_PASS: "secret", CONTACT_TO_EMAIL: undefined, CONTACT_FROM_EMAIL: undefined },
      async () => {
        const before = sink.messages.length;
        const r = await smtpMailer.send(INQUIRY);
        assert.equal(r.delivered, true);
        assert.equal(r.via, "smtp");
        const m = sink.messages[before];
        assert.deepEqual(m.to, ["stadosuyos@gmail.com"]);
        assert.equal(m.from, "site@example.com");
        assert.deepEqual(m.auth, { user: "site@example.com", pass: "secret" });
        assert.match(m.data, /^Subject: New project inquiry: ADU & Home Addition from Jane <b>Doe<\/b>/m);
        assert.match(m.data, /^Reply-To: .*jane@example.com/m);
        assert.match(m.data, /^To: stadosuyos@gmail.com/m);
        assert.match(m.data, /multipart\/alternative/);
      },
    ));

  it("sends every submission, one email each", () =>
    withEnv({ SMTP_HOST: "127.0.0.1", SMTP_PORT: String(sink.port), SMTP_SECURE: "false", SMTP_USER: undefined, SMTP_PASS: undefined }, async () => {
      const before = sink.messages.length;
      await smtpMailer.send(INQUIRY);
      await smtpMailer.send({ ...INQUIRY, name: "Second Person" });
      await smtpMailer.send({ ...INQUIRY, name: "Third Person" });
      assert.equal(sink.messages.length, before + 3);
      assert.ok(sink.messages.slice(before).every((m) => m.to[0] === "stadosuyos@gmail.com"));
    }));

  it("refuses to pretend in production when SMTP isn't configured", () =>
    withEnv({ SMTP_HOST: undefined, NODE_ENV: "production", CONTACT_ALLOW_LOG_ONLY: undefined }, async () => {
      await assert.rejects(smtpMailer.send(INQUIRY), /SMTP is not configured/);
    }));

  it("only logs in development when SMTP isn't configured", () =>
    withEnv({ SMTP_HOST: undefined, NODE_ENV: "development" }, async () => {
      const info = console.info;
      console.info = () => {};
      try {
        assert.deepEqual(await smtpMailer.send(INQUIRY), { delivered: false, via: "log" });
      } finally {
        console.info = info;
      }
    }));

  it("surfaces SMTP connection failures", () =>
    withEnv({ SMTP_HOST: "127.0.0.1", SMTP_PORT: "1", SMTP_SECURE: "false" }, async () => {
      await assert.rejects(smtpMailer.send(INQUIRY));
    }));
});
